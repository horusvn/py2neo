from setuptools import setup

setup(
    name='py2neo',
    version='0.0.1',
    description='a pip-installable package example',
    license='MIT',
    packages=['py2neo'],
    author='Duy Le',
    author_email='le.duy@horus.com.vn',
    keywords=['example'],
    url='https://github.com/horusvn/py2neo'
)
